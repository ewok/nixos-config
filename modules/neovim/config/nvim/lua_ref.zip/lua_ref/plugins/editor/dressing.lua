return { "stevearc/dressing.nvim", event = { "VeryLazy" }, config = false }
