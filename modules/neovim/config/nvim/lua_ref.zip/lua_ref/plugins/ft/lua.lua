return {
    { "folke/neodev.nvim", opts = {}, ft = { "lua" } },
}
