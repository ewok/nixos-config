return { "chaoren/vim-wordmotion", config = false, event = { "BufReadPre", "BufNewFile" } }

