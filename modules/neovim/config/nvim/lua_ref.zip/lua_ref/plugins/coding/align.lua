return {
    "junegunn/vim-easy-align",
    keys = {
        { "ga", "<Plug>(LiveEasyAlign)", mode = { "n", "x" }, desc = "Align Block" },
    },
}
