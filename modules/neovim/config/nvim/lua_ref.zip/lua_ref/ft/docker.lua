local lib = require("lib")

lib.reg_lsp({ "dockerls" })
